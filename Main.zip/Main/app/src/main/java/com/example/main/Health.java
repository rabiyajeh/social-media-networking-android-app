package com.example.main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Health extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health);
    }
}