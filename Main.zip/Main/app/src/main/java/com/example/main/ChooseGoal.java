package com.example.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class ChooseGoal extends AppCompatActivity implements View.OnClickListener {
    private CardView skillCard,languageCard,healthCard;
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_goal);
        skillCard=(CardView)findViewById(R.id.skill_card);
        languageCard=(CardView)findViewById(R.id.language_card);
        healthCard=(CardView)findViewById(R.id.health_card);
        skillCard.setOnClickListener(this);
        languageCard.setOnClickListener(this);
        healthCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
      Intent i ;
      switch(v.getId()) {
          case R.id.skill_card : i= new Intent(this, skills.class); startActivity(i); break;
          case R.id.language_card : i= new Intent(this, languages.class); startActivity(i);break;
          case R.id.health_card : i= new Intent(this, Health.class); startActivity(i);break;
          default: break ;

      }

    }
}
