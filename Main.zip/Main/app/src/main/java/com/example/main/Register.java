package com.example.main;


import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.hbb20.CountryCodePicker;

import java.util.Calendar;
import com.example.main.users.User;
import com.example.main.sql.sqlite;


public class Register extends AppCompatActivity {

    private Button CreateAccountButton;
    private EditText RegisterBirthday;
    ImageView calendaricon;
    private int day,month,year;
    private EditText RegisterEmail, RegisterName, RegisterLastName, RegisterPassword ;
    private ProgressDialog loadingBar;
    CountryCodePicker ccp;
    EditText editTextCarrierNumber;
    String email;
    private  sqlite sqlite;
    private User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        ccp = (CountryCodePicker) findViewById(R.id.ccp);
        editTextCarrierNumber = (EditText) findViewById(R.id.editText_carrierNumber);
        ccp.registerCarrierNumberEditText(editTextCarrierNumber);
        ccp.isValidFullNumber();
        ccp.setPhoneNumberValidityChangeListener(new CountryCodePicker.PhoneNumberValidityChangeListener() {
            @Override
            public void onValidityChanged(boolean isValidNumber) {

            }
        });
        ccp.getFormattedFullNumber();


        CreateAccountButton = (Button) findViewById(R.id.register_btn);
        RegisterEmail = (EditText) findViewById(R.id.email);
        RegisterName = (EditText) findViewById(R.id.name);
        RegisterLastName = (EditText) findViewById(R.id.lastname);
        RegisterPassword = (EditText) findViewById(R.id.password);
        email = RegisterEmail.getText().toString();
        RegisterBirthday = (EditText)findViewById(R.id.birthday);
        calendaricon = (ImageView) findViewById(R.id.calendar);

        calendaricon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                day = calendar.get(Calendar.DAY_OF_MONTH);
                month = calendar.get(Calendar.MONTH);
                year = calendar.get(Calendar.YEAR);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Register.this, android.R.style.Theme_DeviceDefault_Dialog, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        RegisterBirthday.setText(day +"/" + month +"/" + year);
                    }
                }, year, month, day);

                datePickerDialog.show();
            }
        });
        RegisterBirthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                day = calendar.get(Calendar.DAY_OF_MONTH);
                month = calendar.get(Calendar.MONTH);
                year = calendar.get(Calendar.YEAR);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Register.this, android.R.style.Theme_Holo_Dialog_MinWidth, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        RegisterBirthday.setText(day +"/" + month +"/" + year);
                    }
                }, year, month, day);

                datePickerDialog.show();
            }
        });



        CreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateAccount();




            }
        });
        sqlite = new sqlite(this);
        user = new User();
    }


    public static boolean isValidEmail(CharSequence email) {
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }


    private void CreateAccount() {
        String email = RegisterEmail.getText().toString();
        String name = RegisterName.getText().toString();
        String lastname = RegisterLastName.getText().toString();
        String password = RegisterPassword.getText().toString();
        String birthday = RegisterBirthday.getText().toString();
        String phone = editTextCarrierNumber.getText().toString();
        loadingBar = new ProgressDialog(this);
        if (TextUtils.isEmpty(email)) {
            RegisterEmail.setError("Enter a valid mail");
        }
        if (TextUtils.isEmpty(name)) {
            RegisterName.setError("Please enter your name");
        } else if (TextUtils.isEmpty(lastname)) {
            RegisterLastName.setError("Please enter your lastname");
        } else if (TextUtils.isEmpty(password)) {
            RegisterPassword.setError("Please enter a password");
        } else if (TextUtils.isEmpty(birthday)) {
            RegisterBirthday.setError("Please enter your birthday date");
        } else if (TextUtils.isEmpty(phone)) {
            editTextCarrierNumber.setError("Please enter your number phone");
        } else if (!isValidEmail(email)) {
            RegisterEmail.setError("Invalid Email Address");
        }
        else{
            Boolean checkMailInDB = sqlite.checkMailInDB(email);
            if (checkMailInDB==true){
                Boolean insert= sqlite.addUser(user);
                if(insert==true){
                    Toast.makeText(getApplicationContext(),"Registred Successfully",Toast.LENGTH_SHORT);
                    Intent i = new Intent(Register.this, ChooseGoal.class);
                    startActivity(i);
                }
            }
            else {
                Toast.makeText(getApplicationContext(),"Email already exists",Toast.LENGTH_SHORT);
            }

        } } }
    /*   else {
            if (!sqlite.checkUser(RegisterEmail.getText().toString().trim())) {

                user.setName(RegisterName.getText().toString().trim());
                user.setMail(RegisterEmail.getText().toString().trim());
                user.setPassword(RegisterPassword.getText().toString().trim());
                sqlite.addUser(user);
                Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_SHORT);
                Intent i = new Intent(Register.this, ChooseGoal.class);
                startActivity(i);
            }
            else {
                Toast.makeText(getApplicationContext(),"Email already exists",Toast.LENGTH_SHORT);
            }
        } }}*/





